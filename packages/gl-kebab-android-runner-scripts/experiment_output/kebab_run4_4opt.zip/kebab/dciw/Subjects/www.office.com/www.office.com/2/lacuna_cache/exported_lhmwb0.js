
        var aadUserForgetUrlFormat = "https://login.microsoftonline.com/forgetuser?sessionid="
    