
        /*<![CDATA[*/
        var bbcdotcom = {
            adverts: {
                keyValues: {
                    set: function() {}
                }
            },
            advert: {
                write: function() {},
                show: function() {},
                isActive: function() {},
                layout: function() {}
            },
            config: {
                init: function() {},
                isActive: function() {},
                setSections: function() {},
                isAdsEnabled: function() {},
                setAdsEnabled: function() {},
                isAnalyticsEnabled: function() {},
                setAnalyticsEnabled: function() {},
                setAssetPrefix: function() {},
                setFlagpoles: function() {},
                setVersion: function() {},
                setJsPrefix: function() {},
                setSwfPrefix: function() {},
                setCssPrefix: function() {},
                setConfig: function() {},
                getAssetPrefix: function() {},
                getJsPrefix: function() {},
                getSwfPrefix: function() {},
                getCssPrefix: function() {},
                isOptimizelyEnabled: function() {}
            },
            survey: {
                init: function() {}
            },
            data: {},
            init: function() {},
            objects: function(str) {},
            locale: {
                set: function() {},
                get: function() {}
            },
            setAdKeyValue: function() {},
            utils: {
                addEvent: function() {},
                addHtmlTagClass: function() {},
                log: function() {}
            },
            addLoadEvent: function() {}
        }; /*]]>*/
    