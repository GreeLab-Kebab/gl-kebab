
        if (window.bbcdotcom && bbcdotcom.data.ads == 1) {
            document.write('<meta name="google-site-verification" content="auTeTTwSt_KBY_4iDoR00Lwb7-qzx1IgzJy6ztaWgEI" />');
        }
    