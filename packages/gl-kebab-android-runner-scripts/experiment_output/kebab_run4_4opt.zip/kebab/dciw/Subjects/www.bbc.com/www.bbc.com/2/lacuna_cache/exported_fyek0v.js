
        require.config({
            "paths": {
                "orb/async/_footerpromo": 'https://nav.files.bbci.co.uk/navpromo/3.0.0-13.dc6b5c1/js/async/_footerpromo'
            }
        });
    