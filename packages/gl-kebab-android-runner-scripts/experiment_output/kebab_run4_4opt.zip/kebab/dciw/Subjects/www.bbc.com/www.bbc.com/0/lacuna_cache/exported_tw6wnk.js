
        if (window.bbcdotcom && bbcdotcom.data.stats == 1) {
            document.write('<link rel="dns-prefetch" href="//secure-us.imrworldwide.com/">');
            document.write('<link rel="dns-prefetch" href="//me-cdn.effectivemeasure.net/">');
            document.write('<link rel="dns-prefetch" href="//ssc.api.bbc.com/">');
        }
        if (window.bbcdotcom && bbcdotcom.data.ads == 1) {
            document.write('<link rel="dns-prefetch" href="//www.googletagservices.com/">');
            document.write('<link rel="dns-prefetch" href="//bbc.gscontxt.net/">');
            document.write('<link rel="dns-prefetch" href="//tags.crwdcntrl.net/">');
            document.write('<link rel="dns-prefetch" href="//ad.crwdcntrl.net/">');
        }
    