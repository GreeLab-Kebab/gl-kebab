
            /*<![CDATA[*/
            if (window.bbcdotcom && window.bbcdotcom.analytics && bbcdotcom.config && !bbcdotcom.config.isSportApp() && !bbcdotcom.config.isReel()) {
                bbcdotcom.analytics.page();
            } /*]]>*/
        