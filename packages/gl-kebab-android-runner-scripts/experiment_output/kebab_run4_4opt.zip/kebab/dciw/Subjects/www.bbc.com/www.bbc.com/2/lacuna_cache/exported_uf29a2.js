
                        require(['idcta/statusbar'], function(statusbar) {
                            new statusbar.Statusbar({
                                id: 'idcta-statusbar',
                                publiclyCacheable: true
                            });
                        });
                    