
        if (window.define !== undefined) {
            define('orb/cookies', function() {
                return window.bbccookies;
            });
        }
    