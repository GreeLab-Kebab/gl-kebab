
        window.COOKIES_STATIC_HOST = 'https://nav.files.bbci.co.uk/orbit-webmodules/0.0.1-332.8fd22d2/cookie-banner//cookie-prompt/';
    