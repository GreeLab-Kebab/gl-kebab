
            /*<![CDATA[*/
            if (window.bbcdotcom && bbcdotcom.currencyProviders) {
                bbcdotcom.currencyProviders.postWrite();
            } /*]]>*/
        