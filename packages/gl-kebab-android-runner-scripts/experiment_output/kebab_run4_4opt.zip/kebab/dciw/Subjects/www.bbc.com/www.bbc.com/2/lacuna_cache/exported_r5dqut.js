
        /*<![CDATA[*/
        (function() {
            window.bbcdotcom.bodyFirst = true;
        }()); /*]]>*/
    