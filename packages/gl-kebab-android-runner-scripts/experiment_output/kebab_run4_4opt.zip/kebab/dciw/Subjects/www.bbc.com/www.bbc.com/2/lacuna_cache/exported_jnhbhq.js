
            /*<![CDATA[*/
            (function() {
                if (window.bbcdotcom && bbcdotcom.config.isActive('ads')) {
                    googletag.cmd.push(function() {
                        googletag.display('bbccom_interstitial');
                    });
                }
            }()); /*]]>*/
        