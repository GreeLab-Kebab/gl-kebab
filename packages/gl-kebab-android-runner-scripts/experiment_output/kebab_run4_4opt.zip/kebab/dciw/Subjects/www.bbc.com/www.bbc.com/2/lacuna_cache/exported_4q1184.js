
        if (window.define !== undefined) {
            define('orb/cookies', function() {});
        }
    