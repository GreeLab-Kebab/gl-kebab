
        /*<![CDATA[*/
        var bbcdotcomConfig, googletag = googletag || {};
        googletag.cmd = googletag.cmd || [], bbcdotcomScripts = [], tp = window.tp || [];
        var bbcdotcom = false;
        (function() {
            if (typeof require !== 'undefined') {
                require({
                    paths: {
                        "bbcdotcom": "https://static.bbc.co.uk/bbcdotcom/2.8.0/script"
                    }
                });
            }
        })(); /*]]>*/
    