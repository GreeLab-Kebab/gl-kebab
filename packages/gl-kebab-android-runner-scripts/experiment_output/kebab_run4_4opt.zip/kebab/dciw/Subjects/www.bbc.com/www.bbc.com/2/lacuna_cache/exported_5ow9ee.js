
                            /*<![CDATA[*/
                            (function() {
                                if (window.bbcdotcom && bbcdotcom.slotAsync) {
                                    bbcdotcom.slotAsync("parallax", [1, 2, 3, 4]);
                                }
                            })(); /*]]>*/
                        