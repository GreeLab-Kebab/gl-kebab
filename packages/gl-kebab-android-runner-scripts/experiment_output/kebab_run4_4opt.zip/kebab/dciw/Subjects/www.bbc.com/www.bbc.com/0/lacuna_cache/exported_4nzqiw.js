
        /*<![CDATA[*/
        (function() {
            if (window.bbcdotcom && bbcdotcom.config.isActive('ads')) {
                document.write(unescape('%3Cscript id="gnlAdsEnabled" class="bbccom_display_none"%3E%3C/script%3E'));
            }
            if (window.bbcdotcom && bbcdotcom.config.isActive('analytics')) {
                document.write(unescape('%3Cscript id="gnlAnalyticsEnabled" class="bbccom_display_none"%3E%3C/script%3E'));
            }
        }()); /*]]>*/
    