
        /*<![CDATA[*/
        if (window.bbcdotcom && bbcdotcom.data && bbcdotcom.data.stats && bbcdotcom.data.stats == 1 && bbcdotcom.config && bbcdotcom.config.isLotameEnabled && bbcdotcom.config.isLotameEnabled() && bbcdotcom.lotame) {
            (function() {
                bbcdotcom.lotame.callback();
            })();
        } /*]]>*/
    