
                                                    /*<![CDATA[*/
                                                    (function() {
                                                        if (window.bbcdotcom && bbcdotcom.slotAsync) {
                                                            bbcdotcom.slotAsync("mpu", [1, 2, 3, 4]);
                                                        }
                                                    })(); /*]]>*/
                                                