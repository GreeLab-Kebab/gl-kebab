
        /*<![CDATA[*/
        var _sf_startpt = (new Date()).getTime(); /*]]>*/
    