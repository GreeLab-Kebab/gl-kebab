
        /*<![CDATA[*/
        (function() {
            window.bbcdotcom.head = true;
        }()); /*]]>*/
    