
        window.orb_fig_blocking = true;
        window.bbcredirection = {
            geo: true
        };
    