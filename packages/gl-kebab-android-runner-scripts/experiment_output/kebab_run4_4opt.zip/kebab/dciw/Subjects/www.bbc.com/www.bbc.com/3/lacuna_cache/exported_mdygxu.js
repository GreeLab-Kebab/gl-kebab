
        /*<![CDATA[*/
        var bbcdotcom = {
            adverts: {
                keyValues: {
                    set: null
                }
            },
            advert: {
                write: null,
                show: null,
                isActive: null,
                layout: null
            },
            config: {
                init: null,
                isActive: null,
                setSections: null,
                isAdsEnabled: null,
                setAdsEnabled: null,
                isAnalyticsEnabled: null,
                setAnalyticsEnabled: null,
                setAssetPrefix: null,
                setFlagpoles: null,
                setVersion: null,
                setJsPrefix: null,
                setSwfPrefix: null,
                setCssPrefix: null,
                setConfig: null,
                getAssetPrefix: null,
                getJsPrefix: null,
                getSwfPrefix: null,
                getCssPrefix: null,
                isOptimizelyEnabled: null
            },
            survey: {
                init: null
            },
            data: {},
            init: null,
            objects: null,
            locale: {
                set: null,
                get: null
            },
            setAdKeyValue: null,
            utils: {
                addEvent: null,
                addHtmlTagClass: null,
                log: null
            },
            addLoadEvent: null
        }; /*]]>*/
    