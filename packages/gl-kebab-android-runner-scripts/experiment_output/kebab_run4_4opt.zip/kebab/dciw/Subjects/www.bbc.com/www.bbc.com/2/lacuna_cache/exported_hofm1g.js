
        // Globally available search context
        window.SEARCHBOX = {
            "variant": "default",
            "locale": "en",
            "navSearchboxStaticPrefix": "https://nav.files.bbci.co.uk/searchbox/3.0.0-22.72514fb",
            "searchboxAppStaticPrefix": "https://nav.files.bbci.co.uk/searchbox/3.0.0-22.72514fb/drawer",
            "searchFormHtml": "<div tabindex=\"-1\" data-reactroot=\"\" data-reactid=\"1\" data-react-checksum=\"729995048\"><div data-reactid=\"2\"><section class=\"se-searchbox-panel\" data-reactid=\"3\"><div class=\"se-g-wrap\" data-reactid=\"4\"><div class=\"se-g-layout\" data-reactid=\"5\"><div class=\"se-g-layout__item se-searchbox-title\" aria-hidden=\"true\" data-reactid=\"6\">search</div><div class=\"se-g-layout__item se-searchbox\" data-reactid=\"7\"><form accept-charset=\"utf-8\" id=\"searchboxDrawerForm\" method=\"get\" action=\"https://search.bbc.co.uk/search\" data-reactid=\"8\"><label class=\"se-searchbox__input\" for=\"se-searchbox-input-field\" data-reactid=\"9\"><span class=\"se-sr-only\" data-reactid=\"10\">Search Term</span><input type=\"text\" name=\"q\" value=\"\" id=\"se-searchbox-input-field\" class=\"se-searchbox__input__field\" maxlength=\"512\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\" tabindex=\"0\" data-reactid=\"11\"/></label><input type=\"hidden\" name=\"scope\" value=\"\" data-reactid=\"12\"/><button type=\"submit\" class=\"se-searchbox__submit\" tabindex=\"0\" data-reactid=\"13\">Search</button><button type=\"button\" class=\"se-searchbox__clear se-searchbox__clear--visible\" tabindex=\"0\" data-reactid=\"14\">Close</button></form></div></div></div></section><div aria-live=\"polite\" aria-atomic=\"true\" class=\"se-suggestions-container\" data-reactid=\"15\"><section class=\"se-g-wrap\" data-reactid=\"16\"></section></div></div></div>",
            "searchScopePlaceholder": "",
            "searchScopeParam": "",
            "searchScopeTemplate": "",
            "searchPlaceholderWrapperStart": "",
            "searchPlaceholderWrapperEnd": ""
        };
        window.SEARCHBOX.suppress = false;
        window.SEARCHBOX.searchScope = SEARCHBOX.searchScopeTemplate.split('-')[0];
    