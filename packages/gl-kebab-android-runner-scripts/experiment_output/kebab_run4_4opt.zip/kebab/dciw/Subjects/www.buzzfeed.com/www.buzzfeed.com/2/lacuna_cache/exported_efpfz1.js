
        (function(w) {
            w['bfa'] = w['bfa'] || function() {
                (w['bfa'].c = w['bfa'].c || []).push(arguments)
            };
        })(window);
    