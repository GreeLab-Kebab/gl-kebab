
        (function() {
            if (!window.BZFD.Config.enhanced) {

                window.BZFD.Util.createScript({
                    src: "/static-assets/js/vendor.86729727be5839e91fff.js"
                });
            }


            window.BZFD.Util.createScript({
                src: "/static-assets/js/bfa.d9af4ff5d8e9f6d905cc.js"
            });

        }());
    