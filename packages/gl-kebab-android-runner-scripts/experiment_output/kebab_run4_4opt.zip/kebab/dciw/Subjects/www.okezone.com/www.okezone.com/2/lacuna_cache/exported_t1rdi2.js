
        /*GA send Click*/
        $(function() {
            var channel = 'WP Mobile';

            $('.ga_AdsTester').click(function() {});
            $('.ga_AdsTester').contextmenu(function() {});


        });
    