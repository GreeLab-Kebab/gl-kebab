
        /*GA send Click*/
        $(function() {
            var channel = 'WP Mobile';

            $('.ga_AdsTester').click(null);
            $('.ga_AdsTester').contextmenu(null);


        });
    