
        $(".btn-cls").click(null);
    