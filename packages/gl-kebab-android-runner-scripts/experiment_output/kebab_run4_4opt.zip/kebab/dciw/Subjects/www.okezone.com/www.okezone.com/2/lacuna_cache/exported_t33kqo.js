
        var _comscore = _comscore || [];
        _comscore.push({
                c1: "2",
                c2: "9013027"
            }),
            function() {
                var c = document.createElement("script"),
                    e = document.getElementsByTagName("script")[0];
                c.async = !0, c.src = ("https:" == document.location.protocol ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js", e.parentNode.insertBefore(c, e)
            }();
    