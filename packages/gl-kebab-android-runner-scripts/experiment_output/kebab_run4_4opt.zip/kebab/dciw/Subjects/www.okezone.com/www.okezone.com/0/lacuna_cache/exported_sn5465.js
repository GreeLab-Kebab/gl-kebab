
        $(".btn-cls").click(function() {
            $(".ads-bottom-fixed").hide();
        });
    