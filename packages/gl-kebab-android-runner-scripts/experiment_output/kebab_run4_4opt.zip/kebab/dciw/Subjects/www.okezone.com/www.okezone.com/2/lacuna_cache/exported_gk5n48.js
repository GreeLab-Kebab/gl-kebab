
        var googletag = googletag || {};
        googletag.cmd = googletag.cmd || [];
        googletag.cmd.push(function() {
            googletag.defineSlot('/7108725/MOBILE-CarpetAds', [1, 1], 'div-gpt-ad-1492500559731-0').setTargeting('Kanal', ["WP"]).addService(googletag.pubads()).setCollapseEmptyDiv(true);
            googletag.defineSlot('/7108725/MOBILE-Home-Floating', [
                [320, 510],
                [320, 480],
                [300, 320]
            ], 'div-gpt-ad-1466142981957-0').setTargeting("Kanal", ["WP"]).addService(googletag.pubads()).setCollapseEmptyDiv(true);
            googletag.defineSlot('/7108725/MOBILE-Home-TopCenter', [320, 50], 'div-gpt-ad-1471601548694-0').setTargeting("Kanal", ["WP"]).addService(googletag.pubads()).setCollapseEmptyDiv(true);
            googletag.defineSlot('/7108725/MOBILE-Home-StickyAd', [
                [1, 1],
                [320, 50]
            ], 'div-gpt-ad-1463986968457-0').setTargeting("Kanal", ["WP"]).addService(googletag.pubads()).setCollapseEmptyDiv(true);
            googletag.defineSlot('/7108725/MOBILE-Home-Center1', [
                [320, 50],
                [300, 250],
                [300, 100]
            ], 'div-gpt-ad-1463986407857-0').setTargeting("Kanal", ["WP"]).addService(googletag.pubads()).setCollapseEmptyDiv(true);
            googletag.defineSlot('/7108725/MOBILE-Home-StreamAd1', [
                [300, 250],
                [320, 100]
            ], 'div-gpt-ad-1463986614020-0').setTargeting("Kanal", ["WP"]).addService(googletag.pubads()).setCollapseEmptyDiv(true);
            googletag.defineSlot('/7108725/MOBILE-Home-StreamAd2', [
                [300, 250],
                [320, 100]
            ], 'div-gpt-ad-1463986744618-0').setTargeting("Kanal", ["WP"]).addService(googletag.pubads()).setCollapseEmptyDiv(true);
            googletag.defineSlot('/7108725/MOBILE-NativeAd', [350, 100], 'div-gpt-ad-1536054418332-0').setTargeting("Kanal", ["WP"]).addService(googletag.pubads()).setCollapseEmptyDiv(true);


            googletag.defineSlot('/7108725/MOBILE-SA-Refresh', [1, 1], 'div-gpt-ad-1566361429810-0').setTargeting("Kanal", ["WP"]).addService(googletag.pubads()).setCollapseEmptyDiv(true);
            googletag.pubads().enableSingleRequest();
            googletag.pubads().enableAsyncRendering();
            googletag.enableServices();
        });
    