
        $(".hitshare").click(null);
    