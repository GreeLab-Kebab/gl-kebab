
                        googletag.cmd.push(function() {
                            googletag.display('div-gpt-ad-1471601548694-0');
                        });
                    