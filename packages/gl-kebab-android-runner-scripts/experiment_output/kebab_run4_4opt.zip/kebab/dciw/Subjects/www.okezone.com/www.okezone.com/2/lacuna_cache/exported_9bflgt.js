
        $(".hitshare").click(function(event) {});
    