/* JS Code that was found on HTML events */
