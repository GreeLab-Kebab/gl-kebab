
                        googletag.cmd.push(function() {
                            googletag.display('div-gpt-ad-1466142981957-0');
                        });
                    