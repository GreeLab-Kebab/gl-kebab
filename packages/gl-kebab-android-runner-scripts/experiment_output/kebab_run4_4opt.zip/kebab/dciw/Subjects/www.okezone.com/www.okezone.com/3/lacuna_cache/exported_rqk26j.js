
        /*SEARCH POST*/
        $('#search-top').on('click', null);
        $('#textfield').on('keyup', null);
    