
                                    googletag.cmd.push(function() {
                                        googletag.display('div-gpt-ad-1492500559731-0');
                                    });
                                