/* JS Code that was found on HTML events */
plusSlides(-1);plusSlides(1);currentSlide(1);currentSlide(2);currentSlide(3);