
                                        (function() {
                                            var cx = '005703438322411770421:5mgshgrgx2u';
                                            var gcse = document.createElement('script');
                                            gcse.type = 'text/javascript';
                                            gcse.async = true;
                                            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
                                                '//cse.google.com/cse.js?cx=' + cx;
                                            var s = document.getElementsByTagName('script')[0];
                                            s.parentNode.insertBefore(gcse, s);
                                        })();
                                    